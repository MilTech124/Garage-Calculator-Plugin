module.exports = {
    filenameHashing: false,
}